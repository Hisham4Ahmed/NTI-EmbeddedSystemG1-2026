// doxygen style 
#include "HAL/LCD/LCD_Interface.h"

void main()
{
    LCD_Init(Lcd_8bitMode);
    // LCD_WriteData('H',Lcd_8bitMode);
    LCD_GotoXY(1,8);
    LCD_WriteString("Hesh",Lcd_8bitMode);
}